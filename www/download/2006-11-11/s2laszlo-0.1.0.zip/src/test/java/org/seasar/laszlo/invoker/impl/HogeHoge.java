package org.seasar.laszlo.invoker.impl;

public class HogeHoge {
	public String hello(){
		return "hello";
	}
	
	public String throwException(){
		throw new RuntimeException();
	}
	
}
